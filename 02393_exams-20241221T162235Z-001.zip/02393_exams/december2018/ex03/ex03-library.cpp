#include <iostream>
#include "ex03-library.h"

//Do not modify
TemperatureScalesConverter::TemperatureScalesConverter() 
{
	//By default we add a measurement of 0 C which corresponds to 32 F.
	CTemperatures.push_back(0);
	FTemperatures.push_back(32);
}

//Exercise 3 (a) Check and correct this method
void TemperatureScalesConverter::print()
{
	cout << CTemperatures.size() <<" Celsius measurements:";

	for(int i = 0; i < CTemperatures.size(); i++)
	{
		cout<< ' ' << CTemperatures[i];
	}
	cout << endl;
	
	cout << FTemperatures.size() <<" Fahrenheit measurements:";

	for(int i = 0; i < FTemperatures.size(); i++)
	{
		cout<< ' ' << FTemperatures[i];
	}
	cout << endl;
}

//Exercise 3 (b) Implement this method
double TemperatureScalesConverter::convertToF(double CTemperature)
{	
	// conv to F
	CTemperature = CTemperature*1.8 + 32;

	return CTemperature;
}

//Exercise 3 (c) Implement this method
double TemperatureScalesConverter::convertToC(double FTemperature)
{	
	FTemperature = (FTemperature-32)/1.8;

	return FTemperature;
}

//Exercise 3 (d) Implement this method
bool TemperatureScalesConverter::addMeasurement(string scale, double temperature)
{	
	if (scale == "C")
	{
		CTemperatures.push_back(temperature);
		// conv to F and add to Fvector
		FTemperatures.push_back(convertToF(temperature));

		return true;
	}
	else if (scale == "F")
	{
		FTemperatures.push_back(temperature);
		// conv to c and add to cvector
		CTemperatures.push_back(convertToC(temperature));
		return true;
	}
	else
	{
		return false;
	}

	
}