#ifndef EX04_LIBRARY_H_
#define EX04_LIBRARY_H_
using namespace std;
#include <vector>

class Buffer {
public:
    virtual void write(int v) = 0;
    virtual int read() = 0;
    virtual unsigned int occupancy() = 0;
    virtual ~Buffer();
};

// Task 4(a).  Declare the class AutoSummingBuffer, by extending Buffer

// :public Buffer (extending Buffer (inheritance??))
class AutoSummingBuffer: public Buffer 
{

private:

vector<int> data;
unsigned int maxBuffer;
int defaultValue;
unsigned int writeCount;

public:

// Constructor with 2 inputs
AutoSummingBuffer(unsigned int maxBuffer, int defaultValue);

// overriding methods in buffer
virtual void write(int v);
virtual int read();
virtual unsigned int occupancy();
unsigned int occurrences(int v);

};

#endif /* EX04_LIBRARY_H_ */
