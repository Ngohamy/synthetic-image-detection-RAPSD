#include "ex04-library.h"

#include <cmath>

// Task 4(a).  Write a placeholder implementation of AutoSummingBuffer's
//             constructor and methods

// Task 4(b).  Write a working implementation of write(int v) and occupancy()

// Task 4(c).  Write a working implementation of read()

// Task 4(d).  Write a working implementation of occurrences(int v)


// Constructor
AutoSummingBuffer::AutoSummingBuffer(unsigned int maxBuffer, int defaultValue) 
{   
    // "This" needed as the names are the same, similare to .self in python
    this->defaultValue = defaultValue;
    this->maxBuffer = maxBuffer;
    this->writeCount = 0;
}

// Placeholder implementation of a method
unsigned int AutoSummingBuffer::occupancy() 
{
    if(this->writeCount < this->maxBuffer) 
    {
        return writeCount;
    } else 
    {
        return maxBuffer;
    }
}

void AutoSummingBuffer::write(int v) 
{   
    // Add v to data
    this->data.push_back(v);
    // increase write count
    this->writeCount++;

    // Check if we have exceeded maxBuffer
    if(this->writeCount > this->maxBuffer) 
    {
        int oldSum = this->data[0];
        this->data.erase(this->data.begin());
        this->data[0] = this->data[0] + oldSum;
    }
}

int AutoSummingBuffer::read() 
{
    if(this->data.size()>0) 
    {
        int value = this->data[0];
        this->data.erase(this->data.begin());
        if (this->writeCount > this->maxBuffer) 
        {
            this->writeCount = this->maxBuffer - 1;
        } else 
        {
            this->writeCount--;
        }
        return value;
    } else 
    {
        return this->defaultValue;
    }
}

unsigned int AutoSummingBuffer::occurrences(int v) 
{
    unsigned int occurrences = 0;

    for (auto it = this->data.begin(); it != this->data.end(); it++) 
    {
        if (*it == v)
        {
            occurrences++;
        }
    }
    return occurrences;
}

// Do not modify
Buffer::~Buffer() {
    // Empty destructor
}
