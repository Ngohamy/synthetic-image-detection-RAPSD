#include <iostream>
#include "ex02-library.h"
using namespace std;



// Do not modify
void displayPlaylist(Song *s) {
    if (s == nullptr) {
        return;
    }
    cout << s->title << ", ";
    cout << s->artist << ", ";
    cout << s->genre << ", ";
    cout << s->duration << ", " << endl;
    
    displayPlaylist(s->next);
}

// Task 2(a).  Implement this function
unsigned int totalDuration(Song *s, string genre)
{
    unsigned int total = 0;  // Initialize total duration to 0

    // Traverse the linked list
    while (s != nullptr) 
    {
        // Check if the current song matches the target genre
        if (s->genre == genre) 
        {
            total += s->duration;  // Add the duration to the total
        }
        // Move to the next song in the playlist
        s = s->next;
    }

    return total;  // Return the total duration
}


// Task 2(b).  Implement this function
Song* find(Song *s, unsigned int duration)
{
    Song *head = nullptr;  // Head of the new playlist
    Song *tail = nullptr;  // Tail of the new playlist

    // Traverse the original playlist
    while (s != nullptr)
    {
        if (s->duration > duration) 
        {
            // Dynamically allocate a copy of the current song
            // Song *copiedSong: creating a pointer called copiedSong
            // , Song as a pointer needs to be the same type
            // that it is pointing to, new Song is for dynamic memory
            Song *copiedSong = new Song {s->title, s->artist, s->genre, s->duration, nullptr};

            if (head == nullptr) 
            {
                // Add the first song to the new playlist
                head = copiedSong;
                tail = copiedSong;
            } 
            else 
            {
                // Add the copied song to the end of the playlist
                tail->next = copiedSong;
                tail = tail->next;  // Move the tail pointer forward
            }
        }

        // Move to the next song in the original playlist
        s = s->next;
    }

    return head;  // Return the head of the new playlist
}

Song *&findR(Song *&currSong, unsigned int i, unsigned int n) {
    if(i == n){
        return currSong;
    } else {
        return findR(currSong->next, i+1, n);
    }
}

// Task 2(c).  Implement this function
Song* split(Song *&s, unsigned int pos)
{
    unsigned int count = 0;
    
    // iterate until next song is a nullptr
    for (Song *s2 = s; s2 != nullptr; s2 = s2->next)
    {
        count++;    
    }
    
    // if posistion is less than 1 or larger than count
    if(pos < 1 || pos > count)
    {
        return nullptr;
    }

    // find song at specified position
    Song *&song = findR(s, 0, pos-1);
    Song *temp = song;
    song = nullptr;
    return temp;

}
