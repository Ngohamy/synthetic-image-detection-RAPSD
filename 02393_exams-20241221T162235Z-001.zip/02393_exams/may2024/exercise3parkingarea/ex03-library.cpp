#include <iostream>
#include "ex03-library.h"
using namespace std;

// Do not modify
string ParkingArea::categoryToString(Category c)
{
    switch (c)
    {
    case CAR:
        return "car";
    case MOTORBIKE:
        return "motorbike";
    case TRUCK:
        return "truck";
    default:
        return "";
    }
}

// Do not modify
ParkingArea::ParkingArea() {
    this->parkingSpaces["LYNGBY01"] = CAR;
    this->parkingOccupancy["LYNGBY01"] = {"AB123XY", "Alice"};

    this->parkingSpaces["LYNGBY02"] = CAR;
    this->parkingOccupancy["LYNGBY02"] = {"CD987WQ", "Bob"};

    this->parkingSpaces["LYNGBY03"] = MOTORBIKE;
    this->parkingOccupancy["LYNGBY03"] = {"EF456SA", "Claire"};

    this->parkingSpaces["LYNGBY04"] = CAR;

    this->parkingSpaces["LYNGBY05"] = TRUCK;
    this->parkingOccupancy["LYNGBY05"] = {"GH102MN", "Daisy"};

    this->parkingSpaces["LYNGBY06"] = MOTORBIKE;
}

// Task 3(a).  Implement this method
void ParkingArea::park(string parkingSpaceID, string plate, string owner, Category category)
{
    // Checks if parkingSpaceID is not in parkingSpaces
    if (parkingSpaces.find(parkingSpaceID) == parkingSpaces.end())
    {   
        // Do nothing
        return;
    }
    else 
    {   
        // Check if category of parking space does not
        // equal that of category of veichle
        if (category != parkingSpaces[parkingSpaceID])
        {   
            // Do nothing
            return;
        }
        else
        {   
            // Check if the parking spot is ocupied
            if(parkingOccupancy.find(parkingSpaceID) != parkingOccupancy.end())
            {   
                // do nothing
                return;
            }
            // Not ocupied, register the vehicle
            else
            {
                parkingOccupancy[parkingSpaceID] = {plate, owner};

                //return 0;
            }
        }
    }

}

// Task 3(b).  Implement this method
void ParkingArea::leave(vector<string> plates)
{   
    // for(start, until, increment)
    for (auto it2 = plates.begin(); it2 != plates.end(); it2++) 
    {   
        // Looping over key-value pair in parkingOccupancy
        for (auto r: this->parkingOccupancy) 
        {   
            // r.first = parking space ID (key)
            // r.second = Vehicle occuping spot (the value)
            if(r.second.plate == *it2)
            {   
                // remove parking space ID from parkingOccupancy
                this->parkingOccupancy.erase(r.first);
                break;
            }
        }
    }
}


// Task 3(c).  Implement this method
unsigned int ParkingArea::getEmptySpaces(Category category) 
{   

    int totalSpots = 0;

    // Looping over all key-value pairs in parkingSpaces
    for (auto r: this->parkingSpaces)
    {   
        // If category equals
        if (r.second == category)
        {   
            // if ocupied, do nothing
            if (parkingOccupancy.find(r.first) != parkingOccupancy.end())
            {
                // do nothing
            }
            else
            {
                totalSpots++;
            }
            
        }
    }

    return totalSpots;


}

// Task 3(d).  Implement this method
void ParkingArea::findVehicles(vector<string> owners) 
{   
    // to get 100% we would need to iterate over parkingSpaces first
    // and then check if spot is occupied and then check owner 

    // for(start, until, increment)
    for (auto owner = owners.begin(); owner != owners.end(); owner++)
    {
        // Looping over key-value pair in parkingOccupancy
        // Looping from r to end of parkingOccupancy
        for (auto r: this->parkingOccupancy) 
        {   
            // r.first = parking space ID (key)
            // r.second = Vehicle occuping spot (the value)

            // If the owner of the vehicle occuping the spot
            // equals owner, print ID
            if(r.second.owner == *owner)
            {   
                cout << r.first << endl;
            }
        }
    }
}

// Do not modify
void ParkingArea::display() 
{
    for (auto it = this->parkingSpaces.begin(); it != this->parkingSpaces.end(); it++) 
    {
        cout << "Parking '" << it->first << "' ";
        cout << "is for a " << categoryToString(it->second) << " and ";
        if (this->parkingOccupancy.find(it->first) == this->parkingOccupancy.end()) 
        {
            cout << "is empty" << endl;
        } else 
        {
            cout << "contains a vehicle ";
            cout << " with license plate " << this->parkingOccupancy[it->first].plate;
            cout << " belonging to " << this->parkingOccupancy[it->first].owner << endl;
        }
    }
}
