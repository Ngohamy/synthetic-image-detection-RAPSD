#include <iostream>
#include "ex02-library.h"
using namespace std;

// Task 2(a).  Implement this function
unsigned int length(Elem *list) 
{
    unsigned int lenghtOfList = 0;
    // len = sum of times of every elemement

    while (list!=nullptr)
    {   
        // Add times to lenght
        lenghtOfList += list->times;

        // go to next element
        list = list->next;
    }

    return lenghtOfList;
    
}

// Task 2(b).  Implement this function
Elem* append(Elem *list, int v) 
{   
    // Handle the case where the list is empty
    if (list == nullptr) 
    {
        // Create a new node for the empty list
        Elem *newValue = new Elem{v, 1, nullptr};
        return newValue;
    }

    Elem *head = list;  // Save the head of the list

    // Traverse the list to find the last node
    while (list != nullptr) 
    {   
        // If value v exists in the last node, increment its times and return
        if (list->value == v) 
        {
            list->times++;
            return head;  // Return the head of the updated list
        }
        
        // If this is the last node (next is nullptr), add the new value
        if (list->next == nullptr) 
        {
            Elem *newValue = new Elem{v, 1, nullptr};  // Dynamically allocate new node
            list->next = newValue;
            return head;  // Return the head of the updated list
        }

        // Move to the next node
        list = list->next;
    }

    return head;  // Return the head of the updated list
}


// Task 2(c).  Implement this function
Elem* buildRLEList(int *data, unsigned int n) 
{   

    // Write your code here
    Elem *result = nullptr; // RLE list that will be returned

    for (unsigned int i = 0; i < n; i++) 
    {
        result = append(result, data[i]);
    }
    return result;
}

// Do not modify
void displayRLEList(Elem *list) {
    if (list == nullptr) {
        return;
    }
    cout << " " << list->value << " (x" << list->times << ")";
    displayRLEList(list->next);
}
