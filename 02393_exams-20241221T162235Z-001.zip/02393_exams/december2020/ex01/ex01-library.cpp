#include <iostream>
#include "ex01-library.h"
using namespace std;

// Task 1(a).  Implement this function
Complex **createMatrix(unsigned int m, unsigned int n, Complex c) 
{

    Complex **Matrix = new Complex*[m];
    
    for (unsigned int row = 0; row < m; row++)
    {   
        Matrix[row] = new Complex[n];

        for (unsigned int col =0; col < n; col++)
        {
            Matrix[row][col] = c;
            //cout << Matrix[row][col].im << endl;
        }
    }

    return Matrix;
}


// Task 1(b).  Implement this function
void displayMatrix(Complex **A, unsigned int m, unsigned int n) 
{
    for (unsigned int row = 0; row<m; row++)
    {   

        for (unsigned int col =0; col<n; col++)
        {   
            // if at last col, no space
            if (col == n-1)
            {      
                // if positive
                if (A[row][col].im >= 0)
                {
                    cout << A[row][col].re << "+" << A[row][col].im << "i";
                }
                else 
                {
                    cout << A[row][col].re << A[row][col].im << "i";
                }

            }
            else
            {
                // if positive
                if (A[row][col].im >= 0)
                {
                    cout << A[row][col].re << "+" << A[row][col].im << "i" << " ";
                }
                else 
                {
                    cout << A[row][col].re << A[row][col].im << "i"<< " ";
                }
            }
        }

        cout << endl;
    }
}

// Task 1(c).  Implement this function
Complex **createIdentityMatrix(unsigned int n) 
{   
    Complex c = {0,0};
    // A matrix with only zeros
    Complex **zeroMatrix = createMatrix(n,n,c);

    // Add re=1 on diag
    for (unsigned diag = 0; diag < n; diag++)
    {
        zeroMatrix[diag][diag].re = 1;
    }

    return zeroMatrix;
}

// Function to perform matrix multiplication of two complex matrices
void multMatrix(Complex **A, Complex **B, Complex **C, unsigned int m, unsigned int n, unsigned int p) 
{
    // Outer loop: Iterate over rows of matrix C (same as rows of A)
    for (unsigned int i = 0; i < m; i++) 
    {
        // Middle loop: Iterate over columns of matrix C (same as columns of B)
        for (unsigned int j = 0; j < p; j++) 
        {
            // Initialize the current element C[i][j] to the zero complex number
            // This represents the initial value for the accumulation of the dot product
            C[i][j] = {0, 0};

            // Inner loop: Perform the dot product by iterating over the shared dimension n
            for (unsigned int k = 0; k < n; k++) 
            {
                // Multiply the corresponding elements of A and B
                // A[i][k] comes from row i of A
                // B[k][j] comes from column j of B
                Complex mlt = mult(A[i][k], B[k][j]);

                // Add the result of the multiplication to the accumulator C[i][j]
                // C[i][j] accumulates the sum of all A[i][k] * B[k][j] for k = 0 to n-1
                C[i][j] = add(C[i][j], mlt);
            }
        }
    }
}


// Do not modify
Complex add(Complex c, Complex d) {
    Complex result = { c.re + d.re, c.im + d.im };
    return result;
}

// Do not modify
Complex mult(Complex c, Complex d) 
{
    Complex result;
    result.re = (c.re * d.re) - (c.im * d.im);
    result.im = (c.re * d.im) + (c.im * d.re);
    return result;
}

// Do not modify
void deleteMatrix(Complex **A, unsigned int nRows) {
    for (unsigned int i = 0; i < nRows; i++) { delete[] A[i]; }
    delete[] A;
}
