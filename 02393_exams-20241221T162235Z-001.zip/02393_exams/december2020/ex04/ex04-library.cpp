#include "ex04-library.h"

// Task 4(a).  Write a placeholder implementation of LimitedBuffer's
//             constructor and methods

LimitedBuffer::LimitedBuffer(unsigned int maxCapacity, int defaultValue)
{
    this->maxCapacity = maxCapacity;
    this->defaultValue = defaultValue;
    // initialize as 0
    this->counter = 0;
    this->buffer = buffer;
}

void LimitedBuffer::write(int v)
{      
    // if at max capacity, do nothing
    if (this->counter == this->maxCapacity)
    {
        return;
    }
    // write and count
    else
    {   
        // add v to buffer (write)
        this->buffer.push_back(v);
        // count +1
        this->counter++;
    }

    return;
}

unsigned int LimitedBuffer::occupancy()
{
    return this->counter;
}

int LimitedBuffer::read()
{   
    // if empty, return defaultValue
    if(this->buffer.empty())
    {
        return this->defaultValue;
    }
    else
    {   

        int elementToReturn = this->buffer[0];

        // remove first element in buffer
        this->buffer.erase(this->buffer.begin());
        // count -1
        this->counter--;

        return elementToReturn;
    }
    
}

// Task 4(b).  Write a working implementation of write() and occupancy()

// Task 4(c).  Write a working implementation of read()

// Do not modify
Buffer::~Buffer() {
    // Empty destructor
}
