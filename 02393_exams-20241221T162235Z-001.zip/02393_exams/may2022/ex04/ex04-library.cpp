#include "ex04-library.h"

// Task 4(a).  Write a placeholder implementation of SensorBuffer's
//             constructor and methods

SensorBuffer::SensorBuffer(int defaultValue, int minimum, int maximum)
{
    this->defaultValue = defaultValue;
    this->minimum = minimum;
    this->maximum = maximum;
    // initialize counter as 0
    this->counter = 0;

}

void SensorBuffer::write(int v)
{   
    // value less than minimum, set minimum
    if (v < this->minimum)
    {   
        // add minimum
        this->buffer_data.push_back(this->minimum);
        // add to counter that write has been called
        counter++;
    }
    // value more than maximum, set maximum
    else if (v > this->maximum)
    {
        // add maximum
        this->buffer_data.push_back(this->maximum);
        // add to counter that write has been called
        this->counter++;
    }
    // else, value ok to add
    else
    {
        this->buffer_data.push_back(v);
    }
    
}

int SensorBuffer::read()
{   
    // Defining value we want to return
    int read_value;
    bool returnDefault;

    // if buffer_data is empty, return default
    if (this->buffer_data.empty())
    {   returnDefault = true;
        //return defaultValue;
    }
    else
    {   // Take the last entry of buffer_data
        read_value = this->buffer_data[0];
        // remove last entry of buffer_data
        this->buffer_data.erase(this->buffer_data.begin());

        returnDefault = false;
        //return read_value;
    }

    if (returnDefault==true)
    {
        return defaultValue;
    }
    else
    {
        return read_value;
    }
}

unsigned int SensorBuffer::faults()
{   
    // Return state of counter
    return this->counter;
}

void SensorBuffer::clear()
{      
    // reset counter
    this->counter = 0;

    // pop_back every element in buffer_data
    for (unsigned int i = 0; i < this->buffer_data.size(); i++)
    {
        this->buffer_data.pop_back();
    }
}

// Task 4(b).  Write a working implementation of write() and faults()

// Task 4(c).  Write a working implementation of read()

// Task 4(d).  Write a working implementation of clear()

// Do not modify
Buffer::~Buffer() 
{
    // Empty destructor
}
