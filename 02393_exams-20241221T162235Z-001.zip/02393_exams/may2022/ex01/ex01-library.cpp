#include <iostream>
#include "ex01-library.h"

using namespace std;

// Task 1(a).  Implement this function
Square **createChessboard(unsigned int m, unsigned int n) 
{
    Square **chessboard = new Square*[m]; 

    for (unsigned int row = 0; row < m; row++)
    {
        chessboard[row] = new Square[n];

        for (unsigned int col = 0; col < n; col++)
        {
            chessboard[row][col] = {none, nobody};
        }
    }
    
    return chessboard;
}

// Task 1(b).  Implement this function
void displayChessboard(Square **c,unsigned int m, unsigned int n) 
{
        for (unsigned int row = 0; row < m; row++)
    {
            for (unsigned int col = 0; col < n; col++)
            {   

                // If no piece at tile, show as _
                if (c[row][col].piece == none)
                {   
                    if ((col-1) == n)
                    {
                        cout << "_";
                    }
                    else
                    {
                        cout << "_ ";
                    }
                    
                }
                else if (c[row][col].piece == king)
                {   
                    // White king
                    if (c[row][col].team == white)
                    {
                    if ((col-1) == n)
                    {
                        cout << "k";
                    }
                    else
                    {
                        cout << "k ";
                    }
                    }
                    // Black king
                    else
                    {
                    if ((col-1) == n)
                    {
                        cout << "K";
                    }
                    else
                    {
                        cout << "K ";
                    }
                    }
                }
                else if (c[row][col].piece == queen)
                {
                    // White queen
                    if (c[row][col].team == white)
                    {
                    if ((col-1) == n)
                    {
                        cout << "q";
                    }
                    else
                    {
                        cout << "q ";
                    }
                    }
                    // Black queen
                    else
                    {
                    if ((col-1) == n)
                    {
                        cout << "Q";
                    }
                    else
                    {
                        cout << "Q ";
                    }
                    }
                }
                
            }

        cout << endl;
    }
}

// Task 1(c).  Implement this function
bool move(Square **c, unsigned int m, unsigned int n, int r1, int c1, int r2, int c2) 
{   
    if ((r1 == r2) && (c1 == c2)) 
    {
        return false;
    }
    if ((c[r1][c1].team == nobody) || (c[r1][c1].team == c[r2][c2].team)) 
    {
        return false;
    }
    if ((c[r1][c1].piece == queen) && ((r1 != r2) && (c1 != c2)) && (abs(r1 - r2) != abs(c1 - c2))) 
    {
        return false;
    }
    if ((c[r1][c1].piece == king) && ((abs(r1 - r2) > 1) || (abs(c1 - c2) > 1))) 
    {
        return false;
    }

    // move r1/c1 piece to r2/c2
    c[r2][c2].piece = c[r1][c1].piece;
    c[r2][c2].team = c[r1][c1].team;

    // reset r1/c1
    c[r1][c1].piece = none;
    c[r1][c1].team = nobody;

    return true;
    
}

// Task 1(d).  Implement this function
bool threatened(Square **c, unsigned int m, unsigned int n, int row, int col) 
{
    // Replace the following with your code
    return false;
}

// Do not modify
void deleteChessboard(Square **c, unsigned int m) {
    for (unsigned int i = 0; i < m; i++) {
        delete[] c[i];
    }
    delete[] c;
}
