#include <iostream>
#include "ex02-library.h"
using namespace std;

// Task 2(a).  Implement this function
Elem* reverse(Elem *list) 
{
    // Write your code here
    Elem *prev = nullptr;
    Elem *curr = list;
    Elem *next = nullptr;

    while (curr != nullptr) 
    {
        // Remember the next element to process
        next = curr->next;

        // Make the current element point back to the previous
        curr->next = prev;
        
        // Move the pointers one element ahead
        prev = curr;
        curr = next;
    }

    // prev now contains the first element of the reversed list
    return prev;
}

// Task 2(b).  Implement this function
Elem* concatenate(Elem *list1, Elem *list2) 
{
    // Step 1: Handle edge cases when one of the lists is empty
    if (list1 == nullptr) 
    {
        // If list1 is empty, simply return list2
        return list2;
    }
    if (list2 == nullptr) 
    {
        // If list2 is empty, simply return list1
        return list1;
    }

    // Step 2: Traverse list1 to find its last element
    Elem *last = list1;  // Start from the head of list1
    while (last->next != nullptr) 
    {
        // Move to the next element until the last element is reached
        last = last->next;
    }

    // Step 3: Check if the last element of list1 matches the first of list2
    if (last->value == list2->value) 
    {
        // If the values are the same, merge the two elements:
        // Combine the counts (times) of the last element of list1 and the first of list2
        last->times += list2->times;

        // Link the last element of list1 to the second element of list2
        // This skips the first node of list2, as it has already been merged
        last->next = list2->next;
    } 
    else 
    {
        // If the values are different, just link list2 to the end of list1
        last->next = list2;
    }
    
    // Step 4: Return the head of the resulting concatenated list
    return list1;
}

// Task 2(c).  Implement this function
int sum(Elem *list) 
{   
    // defining the total
    int total = 0;

    // iterate through struct
    while (list != nullptr) 
    {   
        // add value * times
        total += list->value * list->times;
        list = list->next;
    }
    return total;
}

// Do not modify
void displayRLEList(Elem *list) 
{
    if (list == nullptr) {
        return;
    }
    cout << " " << list->value << " (x" << list->times << ")";
    displayRLEList(list->next);
}
