#include <iostream>
#include "ex03-library.h"
using namespace std;

// Do not modify
GroceryList::GroceryList() {
    this->items.push_back("Lasagne");
    this->itemsInfo["Lasagne"] = {1, "With eggs if available"};

    this->items.push_back("Salmon");
    this->itemsInfo["Salmon"] = {500, "Smoked if available"};

    this->items.push_back("Spinach");
    this->itemsInfo["Spinach"] = {300, "Fresh"};

    this->items.push_back("Dessert");
    this->itemsInfo["Dessert"] = {8, "Maybe lagkage?"};
}

// Task 3(a).  Implement this method
void GroceryList::add(string name, unsigned int quantity, string notes) 
{   
    // if item not on list, add to list
    if (this->itemsInfo.find(name)==this->itemsInfo.end())
    {   
        // add last to items
        this->items.push_back(name);
        // add quantity and notes
        this->itemsInfo[name] = {quantity, notes};
    }
    else
    {   
        // add quantity and notes
        this->itemsInfo[name] = {quantity+this->itemsInfo[name].quantity, this->itemsInfo[name].notes + ";" + notes};
    }
    
}

// Task 3(b).  Implement this method
bool GroceryList::remove(string name, unsigned int quantity) 
{
    // if item not on list, return false
    if (this->itemsInfo.find(name)==this->itemsInfo.end())
    {
        return false;
    }
    else 
    {   
        // if items current quantity is lower than quantity to remove
        // return false
        if (this->itemsInfo[name].quantity < quantity)
        {
            return false;
        }
        // if sufficient quantity, remove quantity from list but keep item
        else if (this->itemsInfo[name].quantity > quantity)
        {   
            this->itemsInfo[name].quantity -= quantity;
            return true;
        }
        // if quantity == quantity, remove item
        else
        {   
            //this->items.erase(name);
            // remove from map
            this->itemsInfo.erase(name);
            return true;

        }
    }
}

// Task 3(c).  Implement this method
bool GroceryList::copyEntry(string name, string newName) 
{   
    // if not on list, return false
    if (this->itemsInfo.find(name)==this->itemsInfo.end())
    {
        return false;
    }
    // if newName already exists, return false
    else if (this->itemsInfo.find(newName)!=this->itemsInfo.end()) 
    {
        return false;
    }
    else
    {
        // add newName to items at the end
        this->items.push_back(newName);
        // add newName to itemsInfo with same details of name
        this->itemsInfo[newName] = {this->itemsInfo[name].quantity, this->itemsInfo[name].notes};

        return true;
    }

    
}

// Do not modify
void GroceryList::display() {
    // Write your code here
    for (auto it = this->items.begin(); it != this->items.end(); it++) {
        Info &item = this->itemsInfo[*it];
        cout << "name='" << *it << "'; ";
        cout << "quantity=" << item.quantity << "; ";
        cout << "notes='" << item.notes << "'" << endl;
    }
}