#ifndef EX04_LIBRARY_H_
#define EX04_LIBRARY_H_
using namespace std;
#include <vector>

class Buffer {
public:
    virtual void write(int v) = 0;
    virtual int read() = 0;
    virtual unsigned int occupancy() = 0;
    virtual void reset() = 0;
    virtual ~Buffer();
};

// Task 4(a).  Declare the class FilteringBuffer, by extending Buffer
// Write your code here

class FilteringBuffer: public Buffer 
{
    private:
    int defaultValue;
    vector <int> bufferData; 
    vector <int> bufferDataMemory; 
    unsigned int counter; 
    bool vInMemory;


    public:

    FilteringBuffer(int defaultValue);

    virtual void write(int v);
    virtual int read();
    virtual unsigned int occupancy();
    virtual void reset();

    

};

#endif /* EX04_LIBRARY_H_ */
