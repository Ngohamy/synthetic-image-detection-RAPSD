#include "ex04-library.h"

FilteringBuffer::FilteringBuffer(int defaultValue)
{
    this->defaultValue = defaultValue;
    //this->bufferData =
    //this->bufferDataMemory =
    this->counter = 0;
    // initialize as false
    this->vInMemory = false;
}

void FilteringBuffer::write(int v)
{   
    // loop over bufferDataMemory vector
    for (unsigned int i = 0; i < bufferDataMemory.size(); i++)
    {   
        // if v is in buffer data, do nothing
        if (this->bufferDataMemory[i] == v)
        {   
            this-> vInMemory = true;
            return;
        }
        
    } 

    // if not in buffer data, add
    if (vInMemory==false)
    {   
        // Add v to bufferData
        this->bufferData.push_back(v);
        this->bufferDataMemory.push_back(v);
        this->counter ++;
    }
}

int FilteringBuffer::read()
{   
    int readValue = 0;

    // if empty return defaultValue
    if (this->bufferData.empty())
    {
        return defaultValue;
    }
    else
    {
        // Take the last entry of buffer_data
        readValue = this->bufferData[bufferData.size()-1];
        // remove last entry of buffer_data
        this->bufferData.erase(this->bufferData.end());
        // remove 1 from counter
        this->counter--;

        return readValue;
    }
}

unsigned int FilteringBuffer::occupancy()
{
    return this->counter;
}

void FilteringBuffer::reset()
{

    this->bufferData.clear();
    this->bufferDataMemory.clear();
    this->counter = 0;
}


// Do not modify
Buffer::~Buffer() {
    // Empty destructor
}