#include <iostream>
#include "ex01-library.h"

using namespace std;

// Task 1(a).  Implement this function
Vector **createField(unsigned int m, unsigned int n, Vector v) 
{
    Vector **Field = new Vector*[m];

    for (unsigned int row = 0; row < m; row++)
    {
        Field[row] = new Vector[n];

        for (unsigned int col = 0; col< n; col++)
        {
            Field[row][col] = v;
        }
    }

    return Field;
}

// Task 1(b).  Implement this function
void displayField(Vector **A, unsigned int m, unsigned int n) 
{
    for (unsigned int row = 0; row < m; row++)
    {
        for (unsigned int col = 0; col< n; col++)
        {   
            // If at last column, do not use space in the end
            if (col == (n-1))
            {
                cout << "("<< A[row][col].x << "," << A[row][col].y << ")";
            }
            else
            {
                cout << "("<< A[row][col].x << "," << A[row][col].y << ") ";
            }
            
        }

        cout << endl;
    }
}

// Task 1(c).  Implement this function
void addFields(Vector **A, Vector **B, Vector **C, unsigned int m, unsigned int n) 
{
    for (unsigned int row = 0; row < m; row++)
    {
        for (unsigned int col = 0; col< n; col++)
        {
            C[row][col].x = (A[row][col].x + B[row][col].x);
            C[row][col].y = (A[row][col].y + B[row][col].y);

        }
    }
}

// Task 1(d).  Implement this function
void scaleField(Vector **A, double c, unsigned int m, unsigned int n) 
{
    for (unsigned int row = 0; row < m; row++)
    {
        for (unsigned int col = 0; col< n; col++)
        {
            A[row][col].x = A[row][col].x*c;
            A[row][col].y = A[row][col].y*c;

        }
    }
}

// Do not modify
void deleteField(Vector **A, unsigned int nRows) 
{
    for (unsigned int i = 0; i < nRows; ++i) 
    {
        delete[] A[i];
    }
    delete[] A;
}
