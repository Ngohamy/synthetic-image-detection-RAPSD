#ifndef __ex02_library__
#define __ex02_library__

#include <vector>
#include <string>

using namespace std;

vector<string> match(vector<string> & u,
                     vector<string> & v);

vector<string> read_until(string stop);

void display(vector<string> & u);

#endif
