#include <iostream>
#include "ex02-library.h"
using namespace std;

// Task 2(a).  Implement this function
void displayTeams(TournamentNode *t) 
{
    // Extract the two main branches
    TournamentNode right = *t->right;
    TournamentNode left = *t->left;

    while (t!=nullptr)
    {   
        // if it is a team, we print name
        if (t->nodeType==team)
        {
            cout << t->name << endl;
            // here we need to switch branch to right
            //t = &right;
        }

        t = t->left;
        //r = t->right;
    }

    t = &right;

}

// Task 2(b).  Implement this function
unsigned int matches(TournamentNode *t) {
    // Replace the following with your code
    return 0;
}

// Task 2(c).  Implement this function
string winner(TournamentNode *t) {
    // Replace the following with your code
    return "";
}

// Task 2(d). Implement this function
bool wonAnyMatch(TournamentNode *t, string teamName) {
    // Replace the following with your code
    return false;
}