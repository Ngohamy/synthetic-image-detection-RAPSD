#include <iostream>
#include <random>
#include "ex01-library.h"
#include <cmath>

using namespace std;

// Task 1(a).  Implement this function
Tile **createCavern(unsigned int m, unsigned int n) 
{   

    Tile **cav = new Tile*[m];

    for (unsigned int row = 0; row < m; row++) 
        {
            cav[row] = new Tile[n];
        
            for (unsigned int col = 0; col < n; col++) 
            {   
                // initialize with content: nothing, and explored: false
                cav[row][col] = {nothing, false};
            }
        }
        return cav;

}

// Task 1(b).  Implement this function
void revealCavern(Tile **cav, unsigned int m, unsigned int n) 
{       
        // iterate through rows
        for (unsigned int row = 0; row < m; row++) 
        {   
            // iterate through cols
            for (unsigned int col = 0; col < n; col++) 
            {     
                    // if explored and is a rock, show up as #
                    if (cav[row][col].content == rock)
                    {
                        cout << "#";
                    }
                    else if(cav[row][col].content == player)
                    {
                        cout << "X";
                    }
                    else if(cav[row][col].content == wumpus)
                    {
                        cout << "W";
                    }
                    // else, show up as -
                    else
                    {
                        cout << " ";
                    }

            }
        
            cout << endl;
        }
}

// Task 1(c).  Implement this function
bool movePlayer(Tile **cav, int m, int n, int r, int c) 
{    
    // coordinates of player
    int x =0;
    int y =0;

    // loop over all tiles
    for (unsigned int row = 0; row < m; row++) 
    {
        for (unsigned int col = 0; col < n; col++) 
        {   
            if (cav[row][col].content==player)
            {
                x = row;
                y = col;
            }
        }
    }

    // out of bounds or if more than 5 tiles away
    if (r >= m || c >= n || r < 0 || c < 0)
    {
        return false;
    }
    // if something is on the tile
    else if(cav[r][c].content==rock || cav[r][c].content==wumpus)
    {
        return false;
    }
    else if(sqrt(((x-r)^2) + ((y-c)^2)) >= 5)
    {
        return false;
    }
    else
    {   
        // remove player from last tile and set to exlored
        cav[x][y].content = nothing;
        cav[x][y].explored = true;

        // move player and set to explored
        cav[r][c].content = player;
        cav[r][c].explored = true;

        return true;
    }
    
}

// Task 1(d).  Implement this function
void drawCavern(Tile **cav, unsigned int m, unsigned int n) 
{
    // coordinates of player
    int x;
    int y;

    // loop over all tiles to find player
    for (unsigned int row = 0; row < m; row++) 
    {
        for (unsigned int col = 0; col < n; col++) 
        {   
            if (cav[row][col].content==player)
            {
                x = row;
                y = col;
            }
        }
    }

    // iterate through rows
    for (unsigned int row = 0; row < m; row++) 
    {   
        // iterate through cols
        for (unsigned int col = 0; col < n; col++) 
        {   
            // If dist not less than 4
            if (sqrt(((x-row)^2) + ((y-col)^2)) >= 4)
            {   
                // if not explored, print as ?
                if (cav[row][col].explored == false)
                {
                    cout << "?";
                }
                // if explored, print as content
                else
                {   // print rock as #
                    if (cav[row][col].content == rock)
                    {
                        cout << "#";
                    }
                    // print nothing as -
                    else
                    {
                        cout << "-";
                    }
                }
            }
            // if within dist 4
            else
            {   
                // set explored to true
                cav[row][col].explored = true;

                // print rock as #
                if (cav[row][col].content == rock)
                {
                    cout << "#";
                }
                // print wumpus as W
                else if(cav[row][col].content == wumpus)
                {
                    cout << "W";
                }
                // print player as X
                else if(cav[row][col].content == player)
                {
                    cout << "X";
                }
                else
                {
                    cout << " ";
                }
 
            }

        }
        
        cout << endl;
    }
}

// Do not modify the following function.
// This code (that you don't need to read) places the player
// at location (0,0) and pseudo-randomly places some rocks
// and a Wumpus. The pseudo-random placement depends on the
// value of 'seed'.
void setupCavern(Tile **cav, unsigned int m, unsigned int n,
                 unsigned int seed) {
    mt19937 e; // Pseudo-random number generator
    e.seed(seed);

    // 1/3rd of the tiles are rocks
    unsigned int rocks = (m * n) / 3;
    for (unsigned int i = 0; i < rocks; i++) {
        cav[e()%m][e()%n].content = rock;
    }

    // We never place the Wumpus on row 0 or column 0
    unsigned int row = (e() % (m-1)) + 1;
    unsigned int col = (e() % (n-1)) + 1;
    cav[row][col].content = wumpus;

    cav[4][7].content = player;
}

// Do not modify the following function.
void deleteCavern(Tile **c, unsigned int m) {
    for (unsigned int i = 0; i < m; i++) {
        delete[] c[i];
    }
    delete[] c;
}
