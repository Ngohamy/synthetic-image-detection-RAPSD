#include "ex04-library.h"
#include <bits/stdc++.h>

// Task 4(a).  Write a placeholder implementation of CountingBuffer's
//             constructor and methods

CountingBuffer::CountingBuffer(int defaultValue)
{
    this->defaultValue = defaultValue;
}

// Task 4(b).  Write a working implementation of write() and frequency()

void CountingBuffer::write(int v)
{
    bufferData.push_back(v);
}

unsigned int CountingBuffer::frequency(int v)
{   
    unsigned int counter = 0;
    // to store value of freq
    frequencies[v] = 0;

    for (auto i:bufferData)
    {
        if (i==v)
        {
            counter++;
        }
    }

    // add freq to v
    frequencies[v] = counter;

    return counter;
}

// Task 4(c).  Write a working implementation of mostFrequent()

int CountingBuffer::mostFrequent()
{   
    //vector<int> freqiencies;
    int current;
    int valmostFreq;
    int mostFreq = 0;

    // run frequency for all v in buffeData
    for (auto v:bufferData)
    {
        frequency(v);
    }

    // return default if empty
    if (bufferData.empty())
    {
        return defaultValue;
    }
    else
    {  
        // loop over key-value in frequencies
        for (auto freq: frequencies)
        {   
            // grab current freq
            current = freq.second;

            if (current > mostFreq)
            {   
                // set mpstFreq to current and continue
                mostFreq = current;

                // grab val of most freq
                valmostFreq = freq.first;
            }
            
        }

        return valmostFreq;
    }
    //      // loop over v in bufferData
    //     for (unsigned int i = 0; i < bufferData.size(); i++)
    //     {   
    //         // store freq for i in bufferData
    //         freqiencies.push_back(frequency(bufferData[i]));
    //     }

    //     maximum_index = *max_element(freqiencies.begin(), freqiencies.end());

    //     return bufferData[maximum_index];
    // }

    // return 0;
}

// Task 4(d).  Write a working implementation of clear()

void CountingBuffer::clear()
{
    bufferData.clear();
    frequencies.clear();
}

// Do not modify
Buffer::~Buffer() {
    // Empty destructor
}
