#ifndef EX04_LIBRARY_H_
#define EX04_LIBRARY_H_
#include <vector>
#include <map>
using namespace std;

class Buffer 
{
public:
    virtual void write(int v) = 0;
    virtual void clear() = 0;
    virtual ~Buffer();
};

// Task 4(a).  Declare the class CountingBuffer, by extending Buffer
// Write your code here

class CountingBuffer: public Buffer
{
    private:
    map<int, int> frequencies;
    vector<int> bufferData;
    int defaultValue;

    public:

    CountingBuffer(int defaultValue);

    virtual void write(int v);
    virtual void clear();
    unsigned int frequency(int v);
    int mostFrequent();


};

#endif /* EX04_LIBRARY_H_ */
